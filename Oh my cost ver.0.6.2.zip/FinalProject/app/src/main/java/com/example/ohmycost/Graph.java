package com.example.ohmycost;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.DataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.List;

public class Graph extends AppCompatActivity {
    private Button btnback;
    PieChart pieChart;
    SQLiteDatabase sqLiteDatabase;
    Databasemanager mHelper;
    PieDataSet pieDataSet;
    ArrayList<DataSet> dataSets = new ArrayList<>();
    String date;

    public Graph() {

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);

        btnback =(Button)findViewById(R.id.bottonback);
        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Graph.this,MainActivity.class);
                startActivity(intent);
            }
        });

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            date = bundle.getString("EXTRA_DATE"); }

       mHelper = new Databasemanager(this);
        sqLiteDatabase = mHelper.getWritableDatabase();

        pieChart = (PieChart) findViewById(R.id.piechart);
        pieChart.setUsePercentValues(true);
        pieChart.getDescription().setEnabled(false);
        pieChart.setDragDecelerationFrictionCoef(0.90f);

        pieChart.setTransparentCircleRadius(61f);
        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleColor(Color.WHITE);
        MoneyList moneyList = new MoneyList();
        List<String> costList = mHelper.getCostList(date);

        ArrayList<PieEntry> dataV = new ArrayList<>();
        dataV.add(new PieEntry(mHelper.getDayCost(), mHelper.getTypes()));

        PieDataSet dataSet = new PieDataSet(dataV,"Type");
        dataSet.setSelectionShift(5f);
        dataSet.setColors(ColorTemplate.JOYFUL_COLORS);

        PieData data = new PieData((dataSet));
        data.setValueTextSize(10f);
        data.setValueTextColor(Color.GREEN);
        pieChart.setData((data));


    }



}