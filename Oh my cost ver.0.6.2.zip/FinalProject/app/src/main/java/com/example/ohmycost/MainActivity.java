package com.example.ohmycost;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.CalendarView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private CalendarView mCalendarView;
    private TextView theDate;
    private TextView dayTotal;
    private Button btntoADD;
    private Button btntoGraph;
    private String date;
    private String thisdate;
    private String type;
    private double cost;
    private Databasemanager mHelper;
    private List<String> costlist;
    private ArrayAdapter<String> adapter;
    private ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mHelper = new Databasemanager(this);
        dayTotal = (TextView) findViewById(R.id.total2);

        final String format = "%-40s%s%n";


        theDate = (TextView) findViewById(R.id.date);
        Calendar c = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        date = df.format(c.getTime());
        theDate.setText(date);
        list = (ListView)findViewById(R.id.listview);

        costlist = mHelper.getCostList(date);

        mCalendarView = (CalendarView) findViewById(R.id.calendarView);
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String DayOfMonth;
                String Month;
                if(dayOfMonth<10){ DayOfMonth ="0"+ dayOfMonth; } else {DayOfMonth = String.valueOf(dayOfMonth); }
                if(month+1<10){ Month = "0"+ (month+1); } else {Month = String.valueOf(month+1);}
                date = DayOfMonth + "/" + Month +"/" + year;
                Log.d(TAG,"onSelectedDayChange: dd/mm/yyyy: "+date);
                theDate.setText(date);
                if(mHelper.getCostList(date)!=null){
                    costlist = mHelper.getCostList(date);
                    ArrayList<String> costlist2 = new ArrayList<>();
                    for(String costlist1 : costlist ){
                        String[] a = costlist1.split(" ");
                        String b = String.format(format,a[1],a[2]);
                        costlist2.add(b);
                    }
                    adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1, costlist2);
                    list = (ListView)findViewById(R.id.listview);
                    list.setAdapter(adapter);
                    dayTotal.setText("Total : "+String.valueOf(mHelper.getDayCost()));
                }
            }
        });

        btntoADD = (Button) findViewById(R.id.button2);
        btntoADD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,addlist.class);
                intent.putExtra("EXTRA_DATE",date);
                startActivity(intent);
            }
        });

        btntoGraph = (Button)findViewById((R.id.button)) ;
        btntoGraph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(MainActivity.this,Graph.class);
                intent2.putExtra("EXTRA_DATE",date);
                startActivity(intent2);
            }
        });

        if(mHelper.getCostList(date)!=null){
            costlist = mHelper.getCostList(date);
            ArrayList<String> costlist2 = new ArrayList<>();
            for(String costlist1 : costlist ){
                String[] a = costlist1.split(" ");
                String b = String.format(format,a[1],a[2]);
                costlist2.add(b);
            }
            adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1, costlist2);

            list.setAdapter(adapter);
            dayTotal.setText("Total : "+ mHelper.getDayCost());
        }

            list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(final AdapterView<?> parent, View view, final int position, long id1) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setMessage("ต้องการแก้ไข/ลบรายการนี้หรือไม่?");
                    builder.setPositiveButton("Edit", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id2) {
                            Intent editing = new Intent(MainActivity.this, addlist.class);
                            String listName = costlist.get(position);
                            int index = listName.indexOf(" ");
                            String columnId = listName.substring(0, index);
                            editing.putExtra("EXTRA_ID", columnId);
                            startActivity(editing);
                        }
                    });
                    builder.setNegativeButton("Delete", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            AlertDialog.Builder builder =
                                    new AlertDialog.Builder(MainActivity.this);
                            builder.setTitle("Delete this?");
                            builder.setMessage("Are you sure to delete this?");
                            builder.setPositiveButton(getString(android.R.string.ok),
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            String listName = costlist.get(position);
                                            int index = listName.indexOf(" ");
                                            String columnId = listName.substring(0, index);
                                            mHelper.deleteCost(columnId);
                                            finish();
                                            startActivity(getIntent());
                                        }
                                    });

                            builder.setNegativeButton(getString(android.R.string.cancel), null);

                            builder.show();

                        }
                    });
                    builder.show();
                }
            });


    }

}