package com.example.ohmycost;

public class MoneyList {
    private String type;
    private double money;
    public MoneyList(String type,double money){
        this.type = type;
        this.money = money;
    }

    public double getMoney() {
        return money;
    }

    public String getType() {
        return type;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    public void setType(String type) {
        this.type = type;
    }
}
