package com.example.ohmycost;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;

import android.app.Dialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class addlist extends AppCompatActivity  {
    public static final String EXTRA_NUMBER ="com.example.ohmycost.EXTRA_NUMBER";
    public static final String EXTRA_TYPE ="com.example.ohmycost.EXTRA_TYPE";
    private ArrayList<String> types = new ArrayList<>();
    private String type;
    private double cost;
    Spinner sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addlist);
        types.add("-select type-");
        types.add("Bus");
        types.add("Food");
        sp = (Spinner)findViewById(R.id.sp);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,types){
            public View getView(int position, View convertView,ViewGroup parent) {

                View v = super.getView(position, convertView, parent);

                ((TextView) v).setGravity(Gravity.CENTER);

                return v;

            }

            public View getDropDownView(int position, View convertView, ViewGroup parent) {

                View v = super.getDropDownView(position, convertView,parent);
                ((TextView) v).setGravity(Gravity.CENTER);


                return v;

            }
        };
        sp.setAdapter(adapter);
        sp.setSelected(false);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, final int position, long id) {
                final Dialog dialog = new Dialog(addlist.this);
                if(position==0){
                    dialog.dismiss();
                }
                else{
                    dialog.show();
                }
                dialog.setTitle("Type Manager");
                dialog.setContentView(R.layout.activity_managetype);
                final EditText selected = (EditText) dialog.findViewById(R.id.textInput);
                Button add = (Button) dialog.findViewById(R.id.addbtn);
                Button update = (Button) dialog.findViewById(R.id.updatebtn);
                Button delete = (Button) dialog.findViewById(R.id.deletebtn);
                final Button select = (Button) dialog.findViewById(R.id.selectbtn);
                Button back = (Button) dialog.findViewById(R.id.backbtn);
                add.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        types.add(selected.getText().toString());
                        type = types.get(position+1);
                        sp.setSelection(position+1);
                        selected.setText(type);
                        dialog.dismiss();
                    }
                });

                update.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        types.set(position,selected.getText().toString());
                        type = selected.getText().toString();
                        selected.setText(type);
                        sp.setSelection(position);
                        dialog.dismiss();
                    }
                });

                delete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        types.remove(position);
                        dialog.dismiss();
                    }
                });

                back.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                select.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        type = types.get(position);
                        selected.setText(type);
                        dialog.dismiss();
                    }
                });
                selected.setText(types.get(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        EditText editText = (EditText) findViewById(R.id.EXTRA_NUMBER);
        try {
            cost = Double.parseDouble(editText.getText().toString().trim());
        } catch (NumberFormatException e) {
            e.printStackTrace();
            cost = 0.0;
        }
        Button btntoMain = (Button) findViewById(R.id.okbtn);
        btntoMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(addlist.this,MainActivity.class);
                intent.putExtra(EXTRA_NUMBER,cost);
                intent.putExtra(EXTRA_TYPE,type);
                startActivity(intent);
            }
        });
    }
}




