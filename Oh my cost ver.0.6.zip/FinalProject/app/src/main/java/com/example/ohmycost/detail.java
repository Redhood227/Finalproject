package com.example.ohmycost;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class detail extends AppCompatActivity {
    Databasemanager mHelper = new Databasemanager(this);
    public ArrayList<String> types;
    private String type;
    private String date;
    private double cost;
    private String id ="";
    private Button mButtonEdit;
    private Button mButtonDelete;
    private MoneyList moneyList;
    Spinner sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        mHelper = new Databasemanager(this);

        Bundle bundle  = getIntent().getExtras();
        if (bundle != null) {
            id = bundle.getString("EXTRA_ID");
            types = bundle.getStringArrayList("EXTRA_TYPES");
        }
        moneyList = mHelper.getCost(id);
        /*sp = (Spinner)findViewById(R.id.sp);
        sp.setSelection(types.indexOf(moneyList.getType()));
        EditText editText = (EditText) findViewById(R.id.Cost);
        editText.setText((int) moneyList.getMoney());*/

        mButtonDelete = (Button) findViewById(R.id.button_delete);
        mButtonEdit = (Button) findViewById(R.id.button_edit);

        mButtonEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent updateIntent = new Intent(detail.this,
                        addlist.class);

                updateIntent.putExtra(MoneyList.Column.ID, moneyList.getId());
                updateIntent.putExtra(MoneyList.Column.Date, moneyList.getDate());
                updateIntent.putExtra(MoneyList.Column.Type, moneyList.getType());
                updateIntent.putExtra(MoneyList.Column.Cost, moneyList.getMoney());

                startActivity(updateIntent);
                overridePendingTransition(android.R.anim.fade_in,
                        android.R.anim.fade_out);
            }
        });

        mButtonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder =
                        new AlertDialog.Builder(detail.this);
                builder.setTitle("Delete this?");
                builder.setMessage("Do you want to delete this?");

                builder.setPositiveButton(getString(android.R.string.ok),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                mHelper.deleteCost(id);

                                Toast.makeText(getApplication(),
                                        "Deleted", Toast.LENGTH_LONG).show();
                                finish();
                            }
                        });

                builder.setNegativeButton(getString(android.R.string.cancel), null);

                builder.show();
            }
        });
    }
}
