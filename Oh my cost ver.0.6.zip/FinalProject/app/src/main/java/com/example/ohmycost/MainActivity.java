package com.example.ohmycost;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.CalendarView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private CalendarView mCalendarView;
    private TextView theDate;
    private TextView dayTotal;
    private Button btntoADD;
    private String date;
    private String thisdate;
    private String type;
    private double cost;
    private Databasemanager mHelper;
    private List<String> costlist;
    private ArrayAdapter<String> adapter;
    private ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dayTotal = (TextView) findViewById(R.id.total2);
        theDate = (TextView) findViewById(R.id.date);
        Calendar c = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        date = df.format(c.getTime());
        theDate.setText(date);
        mCalendarView = (CalendarView) findViewById(R.id.calendarView);
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                date = dayOfMonth + "/0" + (month+1) +"/" + year;
                Log.d(TAG,"onSelectedDayChange: dd/mm/yyyy: "+date);
                theDate.setText(date);
                if(costlist!=null){
                    costlist = mHelper.getCostList(date);
                    adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1, costlist);
                    list = (ListView)findViewById(R.id.listview);
                    list.setAdapter(adapter);
                    dayTotal.setText("Total : "+String.valueOf(mHelper.getDayCost()));
                }
            }
        });

        btntoADD = (Button) findViewById(R.id.button2);
        btntoADD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,addlist.class);
                intent.putExtra("EXTRA_DATE",date);
                startActivity(intent);
            }
        });


        mHelper = new Databasemanager(this);
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            thisdate = bundle.getString("EXTRA_DATE");
            type = bundle.getString("EXTRA_TYPE");
            cost = bundle.getDouble("EXTRA_NUMBER");
            MoneyList moneyList = new MoneyList();
            moneyList.setDate(thisdate);
            moneyList.setType(type);
            moneyList.setMoney(cost);
            mHelper.addCost(moneyList);
        }
        costlist = mHelper.getCostList(date);
        if(mHelper.getCostList(date)!=null){
            adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1, costlist);
            list = (ListView)findViewById(R.id.listview);
            list.setAdapter(adapter);
            dayTotal.setText("Total : "+String.valueOf(mHelper.getDayCost()));
        }
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent detail = new Intent(MainActivity.this, detail.class);
                String listName = costlist.get(position);
                int index = listName.indexOf(" ");
                String columnId = listName.substring(0, index);
                detail.putExtra("EXTRA_ID", columnId);
                startActivity(detail);
            }
        });
    }

}