package com.example.ohmycost;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.DataSet;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.util.ArrayList;

public class lineGraph extends AppCompatActivity {
    private Button btnback;
    Databasemanager dp = new Databasemanager(lineGraph.this);
    Integer[] months ;
    Integer[] cost ;
    ArrayList<String> eveyMonths;
    private LineChart lineChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);

        btnback = (Button) findViewById(R.id.bottonback);
        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(lineGraph.this, MainActivity.class);
                startActivity(intent);    }
        });
        eveyMonths = getMonth();
        months = new Integer[eveyMonths.size()];
        cost = new Integer[eveyMonths.size()];
        for (int i=0; i<eveyMonths.size();i++) {
            int selectMonth = Integer.parseInt(eveyMonths.get(i));
            months[i] = selectMonth;
            cost[i] = getCostTotal(selectMonth);}

       lineChart =(LineChart)findViewById(R.id.linechart);
       ArrayList<>

       lineChart.setDragEnabled(true);
       lineChart.setScaleEnabled(true);
       LineData data = new LineData();
       lineChart.setData(data);


        }
    public int getCostTotal(int month){
            Cursor c = dp.getCost(Integer.toString(month));
            ArrayList<Integer> Data = new ArrayList<>();
            while (c.moveToNext()){
                Data.add(c.getInt(1)); }
            int total = 0; for (int i=0; i<Data.size();i++) {
                total = total+ Data.get(i)

            }
            return; total;
        }
    public ArrayList<String> getMonth() {
            Cursor c = dp.getCostList();
            ArrayList<String>eveyMonths = new ArrayList<>();
            while (c.moveToNext()){
                String month = c.getString(0) ;
                if(!eveyMonths.contains(month)){
                    eveyMonths.add(month) ;
                }
            }
            return; eveyMonths;
        }

        }
}
