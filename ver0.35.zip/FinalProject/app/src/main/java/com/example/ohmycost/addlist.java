package com.example.ohmycost;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;

public class addlist extends AppCompatActivity {
    public static final String EXTRA_NUMBER ="com.example.ohmycost.EXTRA_NUMBER";

    private EditText addBox;
    private Button addButt;
    private Button okButt;
    private Spinner select;

    private ArrayAdapter<String> addAdapter;
    private ArrayList<String> addItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addlist);

        init();
        addButt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addAdapter.notifyDataSetChanged();
        okButt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainActivuty();

            }
        });

            }

            private void openMainActivuty() {
                EditText editText = (EditText) findViewById(R.id.textInputEditText);
                int number = Integer.parseInt(editText.getText().toString());
                Intent intent = new Intent(addlist.this,MainActivity.class);
                intent.putExtra(EXTRA_NUMBER,number);
                startActivity(intent);


            }
        });
    }

    public void init() {

        addButt = (Button) findViewById(R.id.selectbtn);
        okButt = (Button) findViewById(R.id.okbtn);
        select = (Spinner) findViewById(R.id.spinner);

        addItem = new ArrayList<String>();
        addAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.options));
        select.setAdapter(addAdapter);

    }
}
