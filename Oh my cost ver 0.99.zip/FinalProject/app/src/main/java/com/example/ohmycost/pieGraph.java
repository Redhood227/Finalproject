package com.example.ohmycost;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.DataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class pieGraph extends AppCompatActivity {
    private Button btnback;
    private String mouth;
    private String date;
    PieChart pieChart;
    SQLiteDatabase sqLiteDatabase;
    Databasemanager databasemanager;
    PieDataSet pieDataSet;
    HashMap<String, Integer> idMonth;
    Databasemanager dp = new Databasemanager(pieGraph.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);

        btnback = (Button) findViewById(R.id.bottonback);
        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(pieGraph.this, MainActivity.class);
                startActivity(intent);
            }
        });


        databasemanager = new Databasemanager(this);
        sqLiteDatabase = databasemanager.getWritableDatabase();


        mouth = getIntent().getExtras().getString("month");
        idMonth = getMonth(mouth);
        String[] type = new String[idMonth.size()];
        int[] cost = new int[idMonth.size()];

        int i = 0;
        for (HashMap.Entry<String, Integer> entry : idMonth.entrySet()) {
            type[i] = entry.getKey();
            cost[i] = entry.getValue();
            i++;
        }

        pieChart = (PieChart) findViewById(R.id.piechart);
        pieChart.setUsePercentValues(true);
        pieChart.getDescription().setEnabled(false);
        pieChart.setDragDecelerationFrictionCoef(0.90f);

        pieChart.setTransparentCircleRadius(61f);
        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleColor(Color.WHITE);


        PieDataSet dataSet = null;
        dataSet.setSelectionShift(5f);
        dataSet.setColors(ColorTemplate.JOYFUL_COLORS);

        PieData data = new PieData((dataSet));
        data.setValueTextSize(10f);
        data.setValueTextColor(Color.GREEN);
        pieChart.setData((data));

    }

    public HashMap<String, Integer> getMonth(String month) {


        Cursor c;
        c = dp.getCostList(month);

        HashMap<String, Integer> idMonth = new HashMap<>();
        while ((c.moveToNext())) {
            String type = c.getString(0);
            int cost = c.getInt(1);
            if (idMonth.containsKey(type)) {
                int PreCost = idMonth.get(type);
                idMonth.remove(type);
                idMonth.put(type, PreCost + cost);
            } else {
                idMonth.put(type, cost);
            }
            return idMonth;
        }
        return idMonth;
    }
}