package com.example.ohmycost;

import android.provider.BaseColumns;

public class MoneyList {
    private String date;
    private String type;
    private double cost;

    public MoneyList(){

    }

    public MoneyList(String date,String type,double cost){
        this.date = date;
        this.type = type;
        this.cost = cost;
    }

    public String getDate(){
        return date;
    }

    public double getMoney() {
        return cost;
    }

    public String getType() {
        return type;
    }

    public void setMoney(double money) {
        this.cost = money;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setDate(String date) {
        this.date = date;
    }

    //Database
    public static final String DATABASE_NAME = "cost.db";
    public static final int DATABASE_VERSION = 1;
    public static final String TABLE = "Cost";

    public class Column {
        public static final String ID = BaseColumns._ID;
        public static final String Date = "date";
        public static final String Type = "type";
        public static final String Cost = "cost";  }
}
