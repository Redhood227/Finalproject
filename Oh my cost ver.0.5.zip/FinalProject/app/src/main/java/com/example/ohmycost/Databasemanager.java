package com.example.ohmycost;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class Databasemanager extends SQLiteOpenHelper {
    private final String TAG = getClass().getSimpleName();

    private SQLiteDatabase sqLiteDatabase;

    public Databasemanager(Context context) {
        super(context, "cost.db", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_COST_TABLE = String.format("CREATE TABLE %s"+ "(%s INTEGER PRIMARY KEY  AUTOINCREMENT, %s TEXT, %s TEXT, %s REAL)",
        MoneyList.TABLE,MoneyList.Column.ID,MoneyList.Column.Date,MoneyList.Column.Type,MoneyList.Column.Cost);
        Log.i(TAG, CREATE_COST_TABLE);
        db.execSQL(CREATE_COST_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String DROP_COST_TABLE = "DROP TABLE IF EXISTS cost";
        db.execSQL(DROP_COST_TABLE);
        Log.i(TAG, "Upgrade Database from " + oldVersion + " to " + newVersion);
        onCreate(db);
    }

    public List<String> getCostList(String date) {
        List<String> costs = new ArrayList<String>();

        sqLiteDatabase = this.getWritableDatabase();

        Cursor cursor = sqLiteDatabase.query
                (MoneyList.TABLE, null, null, null, null, null, null);

        if (cursor != null) {
            cursor.moveToFirst();
        }

        while(!((Cursor) cursor).isAfterLast()) {
            if(cursor.getString(1).equals(date)){
            costs.add(cursor.getString(2) + " " + cursor.getString(3)); }
            cursor.moveToNext();}

        sqLiteDatabase.close();

        return costs;
    }


    public void addCost(MoneyList cost) {
        sqLiteDatabase = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(MoneyList.Column.Date, cost.getDate());
        values.put(MoneyList.Column.Type, cost.getType());
        values.put(MoneyList.Column.Cost, cost.getMoney());

        sqLiteDatabase.insert(MoneyList.TABLE, null, values);

        sqLiteDatabase.close();
    }

}
