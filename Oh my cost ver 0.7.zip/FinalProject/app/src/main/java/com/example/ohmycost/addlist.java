package com.example.ohmycost;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class addlist extends AppCompatActivity  {
    Databasemanager mHelper = new Databasemanager(this);
    public ArrayList<String> types = new ArrayList<>();
    private String type;
    private String date;
    private double cost;
    private int ID = -1;
    Spinner sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addlist);
        EditText editText = (EditText) findViewById(R.id.Cost);
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            date = bundle.getString("EXTRA_DATE");
            if(bundle.getString(MoneyList.Column.Type)!=null){
                ID = bundle.getInt(MoneyList.Column.ID);
                type = bundle.getString(MoneyList.Column.Type);
                cost = bundle.getDouble(MoneyList.Column.Cost);
                date = bundle.getString(MoneyList.Column.Date);
                /*sp.setSelection(types.indexOf(type));
                editText.setText(String.valueOf(cost));*/
            }
            }

        types.add("-select type-");
        types.add("Bus");
        types.add("Food");
        sp = (Spinner)findViewById(R.id.sp);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,types){
            public View getView(int position, View convertView,ViewGroup parent) {

                View v = super.getView(position, convertView, parent);

                ((TextView) v).setGravity(Gravity.CENTER);

                return v;

            }

            public View getDropDownView(int position, View convertView, ViewGroup parent) {

                View v = super.getDropDownView(position, convertView,parent);
                ((TextView) v).setGravity(Gravity.CENTER);


                return v;

            }
        };
        sp.setAdapter(adapter);
        sp.setSelected(false);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, final int position, long id) {
                final Dialog dialog = new Dialog(addlist.this);
                if(position==0){
                    dialog.dismiss();
                }
                else{
                    dialog.show();
                }
                dialog.setTitle("Type Manager");
                dialog.setContentView(R.layout.activity_managetype);
                final EditText selected = (EditText) dialog.findViewById(R.id.textInput);
                Button add = (Button) dialog.findViewById(R.id.addbtn);
                Button update = (Button) dialog.findViewById(R.id.updatebtn);
                Button delete = (Button) dialog.findViewById(R.id.deletebtn);
                final Button select = (Button) dialog.findViewById(R.id.selectbtn);
                Button back = (Button) dialog.findViewById(R.id.backbtn);
                add.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        types.add(selected.getText().toString());
                        type = types.get(position+1);
                        sp.setSelection(position+1);
                        selected.setText(type);
                        dialog.dismiss();
                    }
                });

                update.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        types.set(position,selected.getText().toString());
                        type = selected.getText().toString();
                        selected.setText(type);
                        sp.setSelection(position);
                        dialog.dismiss();
                    }
                });

                delete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        types.remove(position);
                        dialog.dismiss();
                    }
                });

                back.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                select.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        type = types.get(position);
                        selected.setText(type);
                        dialog.dismiss();
                    }
                });
                selected.setText(types.get(position));
                Intent intent = new Intent(addlist.this,detail.class);
                intent.putExtra("EXTRA_TYPES",types);
            }




            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        Button btntoMain = (Button) findViewById(R.id.okbtn);
        btntoMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    EditText editText = (EditText) findViewById(R.id.Cost);
                    cost = Double.parseDouble(editText.getText().toString()); }
                catch (NumberFormatException e) {
                    e.printStackTrace();
                    cost = 0.0; }
                Intent intent = new Intent(addlist.this,MainActivity.class);
                MoneyList moneyList = new MoneyList();
                moneyList.setDate(date);
                moneyList.setType(type);
                moneyList.setMoney(cost);
                if (ID == -1) {
                    mHelper.addCost(moneyList);
                } else {
                    moneyList.setId(ID);
                    mHelper.updateCost(moneyList);
                }
                startActivity(intent);
            }
        });
    }
}




